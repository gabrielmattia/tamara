# Advanced Notifications - Build customizada para Moodle 4.1+

## O que foi alterado

Apenas o arquivo `version.php`. Nenhum código funcional do plugin foi modificado.

### Mudanças no `version.php`

| Campo | Original (v1.4.3) | Customizado |
|-------|-------------------|-------------|
| `$plugin->requires` | `2018051703` (Moodle 3.5.3) | `2022112800` (Moodle 4.1.0) |
| `$plugin->supported` | (não existia) | `[401, 405]` |
| `$plugin->release` | `v1.4.3` | `v1.4.3-custom-m41` |

### Por que

A versão oficial v1.4.3 declara compatibilidade apenas até Moodle 3.11. As mudanças
acima permitem a instalação em Moodle 4.1.x até 4.5.x (LTS atual). A análise do
código não identificou uso de APIs deprecadas/removidas no Moodle 4.x — todas as
chamadas (block_base, plugin_renderer_base, optional_param, has_capability,
context_system, scheduled_task, privacy provider) continuam válidas em 4.x.

## Procedimento de instalação

1. **Backup completo** do banco de dados e do diretório `moodledata` ANTES de qualquer coisa.
2. Subir em ambiente de **homologação primeiro**.
3. Copiar a pasta `advnotifications` para `<seu-moodle>/blocks/`.
4. Logar como administrador — o Moodle detecta o novo plugin e pede para instalar.
5. Confirmar a instalação (ele cria as tabelas `block_advnotifications` e `block_advnotificationsdissed`).
6. Habilitar em: Administração do site → Plugins → Blocos → Advanced Notifications → marcar "Enable".

## Roteiro de teste em homologação

Antes de promover para produção, validar no mínimo:

- [ ] Instalação concluiu sem erro
- [ ] Página de configurações abre em "Plugins → Blocos → Advanced Notifications"
- [ ] Criar aviso global (site-wide) tipo "info"
- [ ] Logar como aluno em outro navegador/aba anônima — aviso aparece
- [ ] Dispensar o aviso (clicar no X) — some
- [ ] Recarregar a página — aviso continua dispensado
- [ ] Adicionar bloco "Advanced Notifications" dentro de um curso (com edição ligada)
- [ ] Como professor do curso, criar aviso de turma
- [ ] Aluno matriculado naquele curso vê o aviso
- [ ] Aluno NÃO matriculado naquele curso NÃO vê o aviso
- [ ] Testar os 5 tipos de alerta: info, success, warning, danger, announcement
- [ ] Testar com data início/fim configuradas
- [ ] Conferir aparência no tema customizado de vocês (CSS pode precisar de ajuste)

## Pontos de atenção

1. **Visual no tema customizado**: O plugin usa classes Bootstrap padrão (`.alert`,
   `.alert-info`, etc). Se o tema de vocês sobrescreve essas classes, pode haver
   inconsistência visual. Solução: estilizar via SCSS as classes específicas
   `.block_advnotifications` e `.notification-block-wrapper`.

2. **JS depende de jQuery**: ainda é suportado em Moodle 4.x, mas fique atento em
   futuros upgrades de core (4.6+ pode descontinuar).

3. **NÃO gera notificação no sino do Moodle**: lembre-se de que esse plugin só
   exibe banners visuais. Para notificação real (e-mail/sino/app mobile), combinar
   com outro plugin (ex: Notifications Agent / UNIMOODLE).

4. **Em upgrade futuro do Moodle (ex: para 4.6)**: o `supported = [401, 405]` vai
   bloquear a instalação. Será necessário revalidar e ajustar de novo.

## Em caso de erro

Os erros mais prováveis e onde investigar:

- **"Plugin not supported"** durante a instalação: confira se o `supported` está
  como `[401, 405]` no `version.php`.
- **Erro PHP em alguma classe**: vá em Administração do site → Relatórios → Logs
  do servidor para ver o stack trace exato.
- **Bloco aparece mas notificação não renderiza**: inspecione o console do
  navegador (F12) — geralmente é conflito de JS com o tema.
- **Erro de banco na instalação**: verifique se as tabelas `block_advnotifications`
  ou `block_advnotificationsdissed` já não existiam de uma instalação anterior
  parcial.

Em caso de erro persistente, role o ajuste de volta removendo a pasta `advnotifications`
de `blocks/` e rodando a desinstalação pelo painel do Moodle.
